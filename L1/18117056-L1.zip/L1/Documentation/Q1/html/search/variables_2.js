var searchData=
[
  ['data_37',['data',['../structlist.html#a4ddbccf32d392653a07deb6357666932',1,'list']]],
  ['dob_38',['dob',['../structstudent.html#aa7d1b9d272ce6ed84c391f0a9459a133',1,'student']]]
];

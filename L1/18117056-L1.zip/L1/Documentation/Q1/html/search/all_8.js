var searchData=
[
  ['phone_12',['phone',['../structstudent.html#a16d3ecd96186bd7b07525d4b29e13014',1,'student']]],
  ['print_13',['print',['../q1_8c.html#a8097b4ce1139ce2ee095ddedf0a02cf7',1,'q1.c']]],
  ['printlist_14',['printList',['../q1_8c.html#a2f736094bbaa598f70c3e241bad4a1cc',1,'q1.c']]]
];

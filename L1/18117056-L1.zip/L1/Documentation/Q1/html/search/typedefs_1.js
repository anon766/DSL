var searchData=
[
  ['student_49',['student',['../q1_8c.html#a0aae7ef125b291c43dad230e70110d97',1,'q1.c']]]
];

var searchData=
[
  ['name_41',['name',['../structstudent.html#a87db2e64ee10a8c37a9c2657c5da5228',1,'student']]]
];

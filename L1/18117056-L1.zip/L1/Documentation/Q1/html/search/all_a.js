var searchData=
[
  ['read_17',['read',['../q1_8c.html#ae50f452d120813c73f04af8e04f72fd3',1,'q1.c']]],
  ['right_18',['right',['../structlist.html#add6dc1b0f0988063aa7bf3edf418bd1f',1,'list']]],
  ['roll_19',['roll',['../structstudent.html#a75cdd4b437b265402118f48a1062ac91',1,'student']]]
];

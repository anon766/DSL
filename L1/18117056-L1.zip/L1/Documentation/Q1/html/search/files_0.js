var searchData=
[
  ['q1_2ec_26',['q1.c',['../q1_8c.html',1,'']]]
];

var searchData=
[
  ['address_0',['address',['../structstudent.html#ab97d32ab7f6994211ffc7a156b359964',1,'student']]]
];

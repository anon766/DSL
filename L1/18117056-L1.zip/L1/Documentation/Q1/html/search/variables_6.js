var searchData=
[
  ['phone_42',['phone',['../structstudent.html#a16d3ecd96186bd7b07525d4b29e13014',1,'student']]]
];

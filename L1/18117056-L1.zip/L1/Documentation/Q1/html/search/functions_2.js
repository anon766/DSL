var searchData=
[
  ['main_29',['main',['../q1_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'q1.c']]],
  ['modify_30',['modify',['../q1_8c.html#a27594cd80ed8c72da6c88d690e6619ed',1,'q1.c']]]
];

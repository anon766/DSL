var searchData=
[
  ['right_44',['right',['../structlist.html#add6dc1b0f0988063aa7bf3edf418bd1f',1,'list']]],
  ['roll_45',['roll',['../structstudent.html#a75cdd4b437b265402118f48a1062ac91',1,'student']]]
];

var searchData=
[
  ['currentroll_1',['currentRoll',['../q1_8c.html#a5ba01ad840f1deccc078ef80c405d75d',1,'q1.c']]]
];

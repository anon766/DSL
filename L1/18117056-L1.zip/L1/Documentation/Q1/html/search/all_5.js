var searchData=
[
  ['left_7',['left',['../structlist.html#a97d4d3a8e6ca41714783c5b0c54358c3',1,'list']]],
  ['list_8',['list',['../structlist.html',1,'list'],['../q1_8c.html#aa295f649a192b2bcdc06effc2f71dde4',1,'list():&#160;q1.c']]]
];

var searchData=
[
  ['del_27',['del',['../q1_8c.html#a88552a1c7791628f3875b3dc793a5cd8',1,'q1.c']]]
];

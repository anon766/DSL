var searchData=
[
  ['left_40',['left',['../structlist.html#a97d4d3a8e6ca41714783c5b0c54358c3',1,'list']]]
];

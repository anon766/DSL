var searchData=
[
  ['size_20',['size',['../q1_8c.html#a439227feff9d7f55384e8780cfc2eb82',1,'q1.c']]],
  ['sort_21',['sort',['../q1_8c.html#a47fdc9eea42b6975cdc835bb2e08810e',1,'q1.c']]],
  ['student_22',['student',['../structstudent.html',1,'student'],['../q1_8c.html#a0aae7ef125b291c43dad230e70110d97',1,'student():&#160;q1.c']]]
];

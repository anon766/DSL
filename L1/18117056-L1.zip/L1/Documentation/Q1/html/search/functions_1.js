var searchData=
[
  ['insert_28',['insert',['../q1_8c.html#a8f72dea00934209956b1095541ac6710',1,'q1.c']]]
];

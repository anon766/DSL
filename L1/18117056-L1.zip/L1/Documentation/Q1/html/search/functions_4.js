var searchData=
[
  ['read_33',['read',['../q1_8c.html#ae50f452d120813c73f04af8e04f72fd3',1,'q1.c']]]
];

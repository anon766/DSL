var searchData=
[
  ['currentsize_16',['currentSize',['../q2_8c.html#a0c2f9a0a6941e32677f17cadd8626c6f',1,'q2.c']]]
];

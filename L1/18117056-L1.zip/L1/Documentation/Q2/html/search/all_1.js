var searchData=
[
  ['deletel_1',['deleteL',['../q2_8c.html#a99592bf78c555aa549c9e7474c96d517',1,'q2.c']]],
  ['deleter_2',['deleteR',['../q2_8c.html#ad91986da9ece2a1b1bc52fcb878b0c6e',1,'q2.c']]]
];

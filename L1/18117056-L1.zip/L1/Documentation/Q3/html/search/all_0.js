var searchData=
[
  ['b_0',['b',['../q3_8c.html#ae64f53180b5d41e1fbe03fef85cf0b04',1,'q3.c']]],
  ['blueonly_1',['blueOnly',['../q3_8c.html#ab41f190053202d0dace818e7bf2b3baa',1,'q3.c']]],
  ['blueremove_2',['blueRemove',['../q3_8c.html#a9cb766d2b244464413229287eb8cdd15',1,'q3.c']]]
];

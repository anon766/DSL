var searchData=
[
  ['cols_30',['cols',['../q3_8c.html#af5b3493436bd2c5c2537c6e2aeff186f',1,'q3.c']]]
];

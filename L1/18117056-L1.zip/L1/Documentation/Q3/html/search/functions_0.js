var searchData=
[
  ['blueonly_17',['blueOnly',['../q3_8c.html#ab41f190053202d0dace818e7bf2b3baa',1,'q3.c']]],
  ['blueremove_18',['blueRemove',['../q3_8c.html#a9cb766d2b244464413229287eb8cdd15',1,'q3.c']]]
];

var searchData=
[
  ['b_27',['b',['../q3_8c.html#ae64f53180b5d41e1fbe03fef85cf0b04',1,'q3.c']]]
];

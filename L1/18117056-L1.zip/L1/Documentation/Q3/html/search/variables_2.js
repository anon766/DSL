var searchData=
[
  ['r_29',['r',['../q3_8c.html#afbc02cfe334c856f935a9b88e06ff10c',1,'q3.c']]]
];

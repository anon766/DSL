var searchData=
[
  ['write_15',['write',['../q3_8c.html#a10095551d628d05a43a27758f7cf7ab5',1,'q3.c']]]
];

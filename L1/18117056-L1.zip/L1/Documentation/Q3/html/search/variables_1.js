var searchData=
[
  ['g_28',['g',['../q3_8c.html#ab7058cc6e0cec6bdca362a11969375d0',1,'q3.c']]]
];

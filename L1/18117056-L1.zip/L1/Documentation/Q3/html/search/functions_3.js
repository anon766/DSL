var searchData=
[
  ['pixelvalue_22',['pixelValue',['../q3_8c.html#a66e93f3d6145d7f66fbad8faba1f6cec',1,'q3.c']]]
];

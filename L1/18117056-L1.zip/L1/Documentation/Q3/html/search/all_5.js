var searchData=
[
  ['q3_2ec_9',['q3.c',['../q3_8c.html',1,'']]]
];

var searchData=
[
  ['greenonly_19',['greenOnly',['../q3_8c.html#ad1543fdc021f2c0b48bf978ca970b4c4',1,'q3.c']]],
  ['greenremove_20',['greenRemove',['../q3_8c.html#aee9fa0e482e2e12f2d97033e6fbf84c7',1,'q3.c']]]
];
